<?php
/*
=====================================================
 DataLife Engine - by SoftNews Media Group 
-----------------------------------------------------
 https://dle-news.ru/
-----------------------------------------------------
 Copyright (c) 2004,2024 SoftNews Media Group
-----------------------------------------------------
 You use Demo Version of DataLife Engine
=====================================================
*/
?><?php $_F=__FILE__;$_X='P05SPy5dLll1KlkvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1lwbkh4SGFXIDRwZ21MV200cC1wRTdwWj4geD00anpwTzRCV0hwc1s+US5wWS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tWXBdeHguejp1dUJENC1tNGp6OFtRdVktLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVlwaz4uN1tXTF14cChJKXA1b29xLTVvNXFwWj4geD00anpwTzRCV0hwc1s+US5ZLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9ZcHldV3pwST5CNHBXenAuWz54NEl4NEJwRTdwST4uN1tXTF14WS8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vWXBTV0Q0OnAgUUREeld4NDguXS5ZLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1ZcE16NDpwdHZaWHR2c3AgPltwajRFeld4NHBtNGp6WS8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vWSp1WVlXIChwIUI0IFdtNEIocCduYnliYVhTZ2c9c1g9ZydwKXApcDlZCV00SEI0WyhwIn15eTF1QThBcHFvd3BTPltFV0JCNG0icCk7WQldNEhCNFtwKHAnYT5JSHhXPm06cDg4dTg4dSdwKTtZCUJXNChwIn1ISWlXbUxwSHh4NEYueCEicCk7WTJZWVcgcCghV3p6NHhwKCRbPmpHJyBRRERfeng+WzcnQykpcCRbPmpHJyBRRERfeng+WzcnQ3AvcCIiO1lZJCBRRERIWzRIcC9wUlJSfXlPYVlwcHBwUkJXcnBJREh6ei8iano0Qld4Pls5JEJIW2lfeF00RjQyIk5SeDRKeEhbNEhwV0IvIiBRRERfeng+WzcicG1IRjQvIiBRRERfeng+WzcicElESHp6LyJqN3pXajdMNEJXeD5bInB6eDdENC8ialdCeF06VDMlO100V0xdeDp3b28uSjsiTjkkWz5qRycgUUREX3p4Pls3J0MyUnV4NEp4SFs0SE5SdUJXck5ZfXlPYTtZWT9O';$_D=strrev('edoced_46esab');eval($_D('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCdBaFtSYXlESDVwfVEzNl1PPGNtentmdwogbm9nL0NrTjlzMTdTPU0yPlpGMFYuNFlKOFBHSVdxdWxkdEtiWGlCeHZlVVRqRXJMJywnMVpyPExUbGEyIEh1OHFoTTVWbnNSSzN6ZkQwRT1dQz57R1B5Rk5VfW9TbUJYcGUKeC5RW2NpNC83T1dqQUlrZHRZNko5d2J2ZycpOyRfUj1zdHJfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));?>